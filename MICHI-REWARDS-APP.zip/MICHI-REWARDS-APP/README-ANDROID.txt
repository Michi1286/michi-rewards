MICHI REWARDS — paquete de aplicación

Incluye el prototipo actual dentro de www/, preparado como PWA y como base para un contenedor Android con Capacitor.

Para generar el APK:
1. Instala Node.js LTS y Android Studio.
2. En esta carpeta ejecuta: npm install
3. Ejecuta: npx cap add android
4. Ejecuta: npx cap sync android
5. Ejecuta: npx cap open android
6. En Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).

Importante:
- Este paquete todavía usa el almacenamiento local del prototipo.
- No conectar premios reales ni acreditar puntos reales hasta integrar Supabase con validación del lado servidor y políticas RLS.
- Para instalar la PWA, primero debe alojarse en un dominio HTTPS y abrirse en Chrome Android; elegir Instalar aplicación o Añadir a pantalla principal.
